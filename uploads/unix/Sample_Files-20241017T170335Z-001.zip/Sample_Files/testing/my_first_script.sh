#!/bin/bash

#A simple program

echo This is my simple bash script
