#!/bin/bash
echo Counting words in input files
count1=$( wc -w < $1 )
count2=$( wc -w < $2 )

echo Total words in two files is $(expr $count1 + $count2 )

total=$(($count1+$count2))

echo Total words in the two files is $total 
