#!/bin/bash
echo Please specify a directory

read directory

echo Listing all files in $directory directory
file_list=$( ls $directory)

echo The files in $directory are $file_list
