#!/bin/bash

for FILE in ./Data/*
	do
		identifier=$( grep 'South Africa' $FILE)
		if [ -n "$identifier" ]
			then
				echo $(basename -- $FILE) is from South Africa
				echo $identifier
				echo " "
		else
			echo $(basename -- $FILE) is not from South Africa
		fi
	done
