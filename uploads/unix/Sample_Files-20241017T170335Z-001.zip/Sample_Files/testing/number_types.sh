#!/bin/bash
echo Please enter a number
read number

if [ $(( $number%2 )) -eq 0 ]
  then
    echo Your number of even
else
  echo Your number is odd
fi 
