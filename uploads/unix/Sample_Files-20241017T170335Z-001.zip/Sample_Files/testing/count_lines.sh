#!/bin/bash

echo Please enter your full file path

read file

wc -l $file
