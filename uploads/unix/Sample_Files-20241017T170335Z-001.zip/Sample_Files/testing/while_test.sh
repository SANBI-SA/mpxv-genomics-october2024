#!/bin/bash

for i in {1..5}
  do 
    echo $i 
  done

END=5

i=0
while [ $i -lt $END ]
  do 
    echo $i
    ((i++))
  done
