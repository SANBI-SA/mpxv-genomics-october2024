#!/bin/bash
name=Houriiyah
fullname="$name Tegally"
echo My name is $name. 
echo This script is the property of $fullname
