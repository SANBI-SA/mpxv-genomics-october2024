#!/bin/bash
#Making a new destination directory
mkdir new_data_folder

#Copying the files
for FILE in ../../Sample_Files/*
  do 
    echo Copying file $FILE into new folder
    cp $FILE ./new_data_folder/
  done
