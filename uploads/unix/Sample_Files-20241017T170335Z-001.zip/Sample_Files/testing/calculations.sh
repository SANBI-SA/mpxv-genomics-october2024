#!/bin/bash
let value1=100
let value2=200
let value3=300

let total=$value1+$value2+$value3

echo $total
